// Drew Command Center JavaScript - Complete Fixed Version

class DrewCommandCenter {
    constructor() {
        this.currentPage = 'chat';
        this.allChatMessages = [];
        this.selectedFiles = [];
        this.taskFilter = 'all';
        this.activityFilter = 'all';
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupMobileMenu();
        
        // Chat is the default page for all screen sizes (handled by loadPage)
        
        this.loadPage('chat');
        
        // Auto-refresh dashboard stats every 30 seconds (but NOT chat polling)
        setInterval(() => {
            if (this.currentPage === 'dashboard') {
                this.loadDashboardStats();
            }
        }, 30000);
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.dataset.page;
                this.loadPage(page);
            });
        });

        // Chat form
        const chatForm = document.getElementById('chat-form');
        if (chatForm) {
            chatForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.sendMessage();
            });
        }

        // Quick task form
        const quickTaskForm = document.getElementById('quick-task-form');
        if (quickTaskForm) {
            quickTaskForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addQuickTask();
            });
        }

        // Auto-resize chat input + Enter to send
        const chatInput = document.getElementById('chat-input');
        if (chatInput) {
            chatInput.addEventListener('input', () => {
                this.autoResizeTextarea(chatInput);
            });
            chatInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }

        // Chat search functionality
        const chatSearch = document.getElementById('chat-search');
        if (chatSearch) {
            chatSearch.addEventListener('input', (e) => {
                this.filterChatMessages(e.target.value);
            });
        }

        // File upload functionality
        const fileInput = document.getElementById('file-input');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                this.handleFileSelection(e);
            });
        }
    }

    setupMobileMenu() {
        const menuToggle = document.getElementById('mobile-menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        
        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', () => {
                sidebar.classList.toggle('mobile-visible');
            });

            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !menuToggle.contains(e.target)) {
                    sidebar.classList.remove('mobile-visible');
                }
            });
        }
    }

    loadPage(page) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        const navItem = document.querySelector(`[data-page="${page}"]`);
        if (navItem) navItem.classList.add('active');

        // Hide all pages
        document.querySelectorAll('[id$="-page"]').forEach(p => {
            p.classList.add('d-none');
        });

        // Show selected page
        const pageEl = document.getElementById(`${page}-page`);
        if (pageEl) pageEl.classList.remove('d-none');

        // Load page data
        this.currentPage = page;
        this.loadPageData(page);

        // Hide mobile menu
        document.querySelector('.sidebar')?.classList.remove('mobile-visible');
    }

    async loadPageData(page) {
        try {
            switch(page) {
                case 'dashboard':
                    await this.loadDashboardStats();
                    await this.loadRecentActivity();
                    break;
                case 'chat':
                    await this.loadChat();
                    break;
                case 'tasks':
                    await this.loadTasks();
                    break;
                case 'scheduled':
                    await this.loadScheduledJobs();
                    break;
                case 'activity':
                    await this.loadActivity();
                    break;
                case 'stats':
                    await this.loadDetailedStats();
                    break;
                case 'models':
                    await this.loadModels();
                    break;
            }
        } catch (error) {
            console.error(`Error loading ${page} data:`, error);
            this.showError(`Failed to load ${page} data`);
        }
    }

    async loadDashboardStats() {
        try {
            const response = await fetch('/api/stats');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const stats = await response.json();

            const setEl = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.textContent = val;
            };

            setEl('active-tasks-count', stats.active_tasks || 0);
            setEl('completed-today-count', stats.completed_today || 0);
            setEl('scheduled-jobs-count', stats.scheduled_jobs || 0);
            setEl('messages-today-count', stats.messages_today || 0);

        } catch (error) {
            console.error('Error loading dashboard stats:', error);
        }
    }

    async loadDetailedStats() {
        try {
            const [statsRes, modelsRes] = await Promise.all([
                fetch('/api/stats'),
                fetch('/api/models')
            ]);
            
            if (!statsRes.ok) throw new Error(`HTTP ${statsRes.status}`);
            const stats = await statsRes.json();
            const models = modelsRes.ok ? await modelsRes.json() : null;

            const container = document.getElementById('stats-content');
            if (!container) return;

            const anthropic = stats.anthropic_stats || {};
            const modelUsage = anthropic.model_usage || {};
            const history = stats.usage_history || [];
            const costAllTime = anthropic.cost_all_time || 0;

            container.innerHTML = `
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-value">${stats.active_tasks || 0}</div>
                        <div class="stat-label">Active Tasks</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">${stats.total_conversations || 0}</div>
                        <div class="stat-label">Total Messages</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">${stats.scheduled_jobs || 0}</div>
                        <div class="stat-label">Scheduled Jobs</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">${stats.uptime || '—'}</div>
                        <div class="stat-label">Uptime</div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h2>🤖 Anthropic API Usage</h2></div>
                    <div class="card-body">
                        <table class="cost-table">
                            <thead>
                                <tr>
                                    <th>Model</th>
                                    <th>Requests</th>
                                    <th>Tokens</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${Object.entries(modelUsage).map(([name, data]) => `
                                    <tr>
                                        <td style="color:#e0e0e0;font-weight:600">${name}</td>
                                        <td>${(data.requests || 0).toLocaleString()}</td>
                                        <td>${(data.tokens || 0).toLocaleString()}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h2>💰 Cost Summary</h2></div>
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-value" style="color:#28c840">$${(models?.total_cost_today || anthropic.cost_today || 0).toFixed(2)}</div>
                            <div class="stat-label">Today's Cost</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value" style="color:#febc2e">$${(models?.total_cost_month || anthropic.cost_month || 0).toFixed(2)}</div>
                            <div class="stat-label">Monthly Cost</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value" style="color:#6c5ce7">$${(models?.total_cost_all_time || costAllTime || 0).toFixed(2)}</div>
                            <div class="stat-label">All Time Cost</div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h2>⚡ System Health</h2></div>
                    <div class="card-body">
                        <div class="stats-breakdown">
                            <div class="breakdown-item">
                                <span>Status</span>
                                <span class="breakdown-count" style="color:#28c840">✅ ${stats.system_status || 'healthy'}</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Success Rate</span>
                                <span class="breakdown-count">${stats.success_rate || '—'}</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Uptime</span>
                                <span class="breakdown-count">${stats.uptime || '—'}</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Total Activities</span>
                                <span class="breakdown-count">${stats.total_activities || 0}</span>
                            </div>
                        </div>
                    </div>
                </div>

                ${history.length > 0 ? `
                <div class="card">
                    <div class="card-header"><h2>📈 Usage Over Time (14 days)</h2></div>
                    <div class="card-body">
                        <div style="margin-bottom:1.5rem">
                            <h4 style="color:#8b8fa3;font-size:0.85rem;margin-bottom:0.75rem;text-transform:uppercase;letter-spacing:0.5px">Daily Requests</h4>
                            <div style="display:flex;align-items:flex-end;gap:4px;height:120px">
                                ${history.map(d => {
                                    const maxReq = Math.max(...history.map(h => h.requests));
                                    const pct = (d.requests / maxReq * 100);
                                    return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px">
                                        <span style="font-size:0.6rem;color:#8b8fa3">${d.requests}</span>
                                        <div style="width:100%;background:#6c5ce7;border-radius:3px 3px 0 0;height:${pct}%;min-height:4px;transition:height 0.3s" title="${d.label}: ${d.requests} requests"></div>
                                        <span style="font-size:0.55rem;color:#4a5568">${d.label.split(' ')[1]}</span>
                                    </div>`;
                                }).join('')}
                            </div>
                        </div>
                        <div style="margin-bottom:1.5rem">
                            <h4 style="color:#8b8fa3;font-size:0.85rem;margin-bottom:0.75rem;text-transform:uppercase;letter-spacing:0.5px">Daily Cost ($)</h4>
                            <div style="display:flex;align-items:flex-end;gap:4px;height:120px">
                                ${history.map(d => {
                                    const maxCost = Math.max(...history.map(h => h.cost));
                                    const pct = (d.cost / maxCost * 100);
                                    return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px">
                                        <span style="font-size:0.6rem;color:#8b8fa3">$${d.cost}</span>
                                        <div style="width:100%;background:#28c840;border-radius:3px 3px 0 0;height:${pct}%;min-height:4px;transition:height 0.3s" title="${d.label}: $${d.cost}"></div>
                                        <span style="font-size:0.55rem;color:#4a5568">${d.label.split(' ')[1]}</span>
                                    </div>`;
                                }).join('')}
                            </div>
                        </div>
                        <div style="margin-bottom:1rem">
                            <h4 style="color:#8b8fa3;font-size:0.85rem;margin-bottom:0.75rem;text-transform:uppercase;letter-spacing:0.5px">Daily Tokens</h4>
                            <div style="display:flex;align-items:flex-end;gap:4px;height:120px">
                                ${history.map(d => {
                                    const maxTok = Math.max(...history.map(h => h.tokens));
                                    const pct = (d.tokens / maxTok * 100);
                                    return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px">
                                        <span style="font-size:0.6rem;color:#8b8fa3">${(d.tokens/1000).toFixed(0)}k</span>
                                        <div style="width:100%;background:#febc2e;border-radius:3px 3px 0 0;height:${pct}%;min-height:4px;transition:height 0.3s" title="${d.label}: ${d.tokens.toLocaleString()} tokens"></div>
                                        <span style="font-size:0.55rem;color:#4a5568">${d.label.split(' ')[1]}</span>
                                    </div>`;
                                }).join('')}
                            </div>
                        </div>
                    </div>
                </div>
                ` : ''}
            `;
        } catch (error) {
            console.error('Error loading detailed stats:', error);
            this.showError('Failed to load detailed stats');
        }
    }

    async loadModels() {
        try {
            const response = await fetch('/api/models');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();

            // Cost savings
            const costSavings = document.getElementById('cost-savings-content');
            if (costSavings) {
                costSavings.innerHTML = `
                    <div class="cost-savings-grid">
                        <div class="cost-comparison-item current">
                            <div class="cost-amount current">$${(data.total_cost_today || 0).toFixed(2)}</div>
                            <div class="cost-label">Today's Spend</div>
                        </div>
                        <div class="cost-comparison-item alternative">
                            <div class="cost-amount alternative">$${(data.total_cost_month || 0).toFixed(2)}</div>
                            <div class="cost-label">Month to Date</div>
                        </div>
                        <div class="cost-comparison-item savings">
                            <div class="cost-amount savings">$${(data.total_cost_all_time || 0).toFixed(2)}</div>
                            <div class="cost-label">All Time</div>
                        </div>
                    </div>
                `;
            }

            // Current model
            const currentModel = document.getElementById('current-model-display');
            if (currentModel) {
                currentModel.innerHTML = `
                    <div class="current-model-display">
                        <div style="font-size:2rem">🟣</div>
                        <div class="current-model-info">
                            <div class="current-model-name">${data.primary_model || 'claude-sonnet-4'}</div>
                            <div class="current-model-desc">Primary model for all tasks</div>
                            <div class="current-model-pricing">
                                <span>Backup: ${data.backup_model || 'claude-opus-4'}</span>
                            </div>
                        </div>
                    </div>
                `;
            }

            // Model cards
            const modelsGrid = document.getElementById('models-grid');
            if (modelsGrid) {
                const allModels = [];
                
                // Anthropic models
                if (data.anthropic) {
                    for (const [name, info] of Object.entries(data.anthropic)) {
                        allModels.push({
                            name,
                            provider: 'Anthropic',
                            providerEmoji: '🟣',
                            ...info,
                            isPrimary: name === data.primary_model
                        });
                    }
                }
                
                // OpenAI models
                if (data.openai) {
                    for (const [name, info] of Object.entries(data.openai)) {
                        allModels.push({
                            name,
                            provider: 'OpenAI',
                            providerEmoji: '🟢',
                            ...info,
                            isPrimary: false
                        });
                    }
                }

                modelsGrid.innerHTML = allModels.map(model => `
                    <div class="model-card ${model.isPrimary ? 'active' : ''}">
                        <div class="model-header">
                            <div class="model-title">
                                <span class="provider-logo">${model.providerEmoji}</span>
                                <h4>${model.name}</h4>
                            </div>
                            ${model.isPrimary ? '<span class="model-badge">Primary</span>' : ''}
                        </div>
                        <div class="model-pricing">
                            <div class="pricing-grid">
                                <div class="pricing-item">
                                    <span>Requests Today</span>
                                    <span class="price">${(model.requests_today || 0).toLocaleString()}</span>
                                </div>
                                <div class="pricing-item">
                                    <span>Tokens Today</span>
                                    <span class="price">${(model.tokens_today || 0).toLocaleString()}</span>
                                </div>
                                <div class="pricing-item">
                                    <span>Cost Today</span>
                                    <span class="price">$${(model.cost_today || 0).toFixed(2)}</span>
                                </div>
                                <div class="pricing-item">
                                    <span>Total Requests</span>
                                    <span class="price">${(model.requests_total || 0).toLocaleString()}</span>
                                </div>
                            </div>
                        </div>
                        <div style="display:flex;align-items:center;gap:0.5rem;margin-bottom:1rem">
                            <div class="status-indicator status-${model.status || 'active'}">
                                <div class="status-dot"></div>
                                ${model.status || 'healthy'}
                            </div>
                            <span class="text-muted" style="font-size:0.85rem">${model.provider}</span>
                        </div>
                        <button class="model-select-btn ${model.isPrimary ? 'active' : ''}" ${model.isPrimary ? 'disabled' : ''}>
                            ${model.isPrimary ? '✓ Active Model' : 'Select Model'}
                        </button>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading models:', error);
            this.showError('Failed to load models');
        }
    }

    async loadRecentActivity() {
        try {
            const response = await fetch('/api/activity?limit=10');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const activities = await response.json();

            const activityList = document.getElementById('recent-activity');
            if (!activityList) return;
            
            if (activities && activities.length > 0) {
                activityList.innerHTML = activities.map(activity => `
                    <div class="activity-item">
                        <div class="activity-time">${this.formatDateTime(activity.timestamp)}</div>
                        <div class="activity-content">
                            <h4>${this.formatAction(activity.action)}</h4>
                            <p>${activity.summary}</p>
                        </div>
                    </div>
                `).join('');
            } else {
                activityList.innerHTML = '<div class="activity-item"><div class="activity-content"><p class="text-muted">No recent activity</p></div></div>';
            }
        } catch (error) {
            console.error('Error loading recent activity:', error);
        }
    }

    async loadTasks() {
        try {
            const response = await fetch('/api/tasks');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const tasks = await response.json();

            this.allTasks = tasks;
            this.renderTasks(tasks);
            this.setupTaskFilters();
        } catch (error) {
            console.error('Error loading tasks:', error);
            this.showError('Failed to load tasks');
        }
    }

    renderTasks(tasks) {
        const filtered = this.taskFilter === 'all' ? tasks : tasks.filter(t => t.status === this.taskFilter);
        const tasksList = document.getElementById('tasks-list');
        if (!tasksList) return;
        
        if (filtered && filtered.length > 0) {
            tasksList.innerHTML = filtered.map(task => `
                <div class="task-item" data-task-id="${task.id}">
                    <div class="task-title">${task.title}</div>
                    <div class="text-muted" style="font-size:0.85rem;margin:0.25rem 0">${task.description || ''}</div>
                    ${task.progress !== undefined ? `
                        <div style="background:#1e2040;border-radius:4px;height:6px;margin:0.5rem 0;overflow:hidden">
                            <div style="background:${task.progress === 100 ? '#28c840' : '#6c5ce7'};height:100%;width:${task.progress}%;border-radius:4px;transition:width 0.3s"></div>
                        </div>
                    ` : ''}
                    <div class="task-meta">
                        <span class="task-status status-${task.status}">${task.status}</span>
                        <span class="priority-${task.priority}">${task.priority}</span>
                        <span class="text-muted">${task.category || 'general'}</span>
                        <span class="text-muted">${this.formatDate(task.created_at)}</span>
                    </div>
                </div>
            `).join('');
        } else {
            tasksList.innerHTML = '<div class="task-item"><div class="task-title text-muted">No tasks found</div></div>';
        }
    }

    setupTaskFilters() {
        const header = document.querySelector('#tasks-page .card-header .d-flex');
        if (!header) return;
        
        const filters = ['all', 'queued', 'active', 'completed'];
        header.innerHTML = filters.map(f => `
            <button class="btn btn-secondary task-filter-btn ${this.taskFilter === f ? 'active' : ''}" data-filter="${f}" style="${this.taskFilter === f ? 'background:#6c5ce7;color:white' : ''}">
                ${f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
        `).join('');

        header.querySelectorAll('.task-filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.taskFilter = btn.dataset.filter;
                header.querySelectorAll('.task-filter-btn').forEach(b => {
                    b.style.background = '';
                    b.style.color = '';
                });
                btn.style.background = '#6c5ce7';
                btn.style.color = 'white';
                this.renderTasks(this.allTasks || []);
            });
        });

        // New Task button
        const newTaskBtn = document.querySelector('#tasks-page > .d-flex .btn-primary');
        if (newTaskBtn && !newTaskBtn._bound) {
            newTaskBtn._bound = true;
            newTaskBtn.addEventListener('click', () => this.showNewTaskDialog());
        }
    }

    showNewTaskDialog() {
        const title = prompt('Task title:');
        if (!title) return;
        const description = prompt('Description (optional):') || '';
        const priority = prompt('Priority (low/normal/high/urgent):', 'normal') || 'normal';
        
        fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, description, priority })
        }).then(r => {
            if (r.ok) {
                this.showSuccess('Task created!');
                this.loadTasks();
            } else {
                this.showError('Failed to create task');
            }
        }).catch(() => this.showError('Failed to create task'));
    }

    async loadScheduledJobs() {
        try {
            const response = await fetch('/api/scheduled');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const jobs = await response.json();

            const jobsList = document.getElementById('scheduled-list');
            if (!jobsList) return;
            
            if (jobs && jobs.length > 0) {
                jobsList.innerHTML = jobs.map(job => `
                    <div class="card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h3 style="margin-bottom:0.25rem">${job.name}</h3>
                                <p class="text-muted" style="margin-bottom:0.25rem">${job.description || ''}</p>
                                <p class="text-muted" style="font-size:0.85rem">
                                    <code style="background:#1e2040;padding:0.15rem 0.5rem;border-radius:4px">${job.schedule}</code>
                                    &nbsp;•&nbsp; Type: ${job.job_type || 'unknown'}
                                </p>
                            </div>
                            <div style="text-align:right">
                                <div class="status-indicator status-${job.status}">
                                    <div class="status-dot"></div>
                                    ${job.status}
                                </div>
                                ${job.next_run ? `<div class="text-muted mt-1" style="font-size:0.8rem">Next: ${this.formatDateTime(job.next_run)}</div>` : ''}
                                ${job.last_run ? `<div class="text-muted" style="font-size:0.8rem">Last: ${this.formatDateTime(job.last_run)} (${job.last_status || ''})</div>` : ''}
                            </div>
                        </div>
                    </div>
                `).join('');
            } else {
                jobsList.innerHTML = '<div class="card"><p class="text-muted">No scheduled jobs</p></div>';
            }
        } catch (error) {
            console.error('Error loading scheduled jobs:', error);
            this.showError('Failed to load scheduled jobs');
        }
    }

    async loadActivity() {
        try {
            const response = await fetch('/api/activity?limit=50');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const activities = await response.json();

            this.allActivities = activities;
            this.renderActivity(activities);
            this.setupActivityFilters();
        } catch (error) {
            console.error('Error loading activity:', error);
            this.showError('Failed to load activity log');
        }
    }

    renderActivity(activities) {
        const activityList = document.getElementById('activity-list');
        if (!activityList) return;
        
        const filtered = this.activityFilter === 'all' ? activities : 
            activities.filter(a => {
                if (this.activityFilter === 'tasks') return a.action.includes('task');
                if (this.activityFilter === 'chat') return a.action.includes('chat');
                if (this.activityFilter === 'cron') return a.session_type === 'monitoring' || a.action.includes('scheduled');
                return true;
            });
        
        if (filtered && filtered.length > 0) {
            activityList.innerHTML = filtered.map(activity => `
                <div class="activity-item">
                    <div class="activity-time">${this.formatDateTime(activity.timestamp)}</div>
                    <div class="activity-content">
                        <h4>${this.formatAction(activity.action)}</h4>
                        <p>${activity.summary}</p>
                        <p class="text-muted" style="font-size:0.75rem">
                            ${activity.session_type || 'unknown'} • ${activity.user || 'system'}
                        </p>
                    </div>
                </div>
            `).join('');
        } else {
            activityList.innerHTML = '<div class="activity-item"><div class="activity-content"><p class="text-muted">No activity found</p></div></div>';
        }
    }

    setupActivityFilters() {
        const filterContainer = document.querySelector('#activity-page > .d-flex .d-flex');
        if (!filterContainer) return;
        
        const filters = ['all', 'tasks', 'chat', 'cron'];
        filterContainer.innerHTML = filters.map(f => `
            <button class="btn btn-secondary activity-filter-btn" data-filter="${f}" style="${this.activityFilter === f ? 'background:#6c5ce7;color:white' : ''}">
                ${f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
        `).join('');

        filterContainer.querySelectorAll('.activity-filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.activityFilter = btn.dataset.filter;
                filterContainer.querySelectorAll('.activity-filter-btn').forEach(b => {
                    b.style.background = '';
                    b.style.color = '';
                });
                btn.style.background = '#6c5ce7';
                btn.style.color = 'white';
                this.renderActivity(this.allActivities || []);
            });
        });
    }

    // CRITICAL FIX: No more polling, just load messages once
    async loadChat() {
        try {
            const response = await fetch('/api/chat/live?limit=50');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();
            
            if (data.messages) {
                this.allChatMessages = data.messages;
                this.renderChatMessages(data.messages);
                this.scrollChatToBottom();
            }
        } catch (error) {
            console.error('Error loading chat:', error);
            this.showError('Failed to load chat');
        }
    }

    renderChatMessages(messages) {
        const chatMessages = document.getElementById('chat-messages');
        if (!chatMessages) return;
        
        let lastDate = '';
        chatMessages.innerHTML = messages.map(msg => {
            let dateHeader = '';
            const msgDate = msg.session_date || (msg.timestamp ? msg.timestamp.substring(0, 10) : '');
            if (msgDate && msgDate !== lastDate) {
                lastDate = msgDate;
                const dateObj = new Date(msgDate + 'T12:00:00');
                const label = dateObj.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
                dateHeader = `<div style="text-align:center;margin:1.5rem 0 1rem"><div style="display:inline-block;background:#1a1a35;color:#6c5ce7;padding:0.4rem 1.2rem;border-radius:20px;font-size:0.8rem;font-weight:600;border:1px solid #2a2d5a">${label}</div></div>`;
            }
            if (msg.role === 'system') {
                return dateHeader + `
                    <div style="text-align:center;margin:1rem 0">
                        <div style="display:inline-block;background:#1e2040;color:#8b8fa3;padding:0.5rem 1rem;border-radius:20px;font-size:0.85rem">
                            ${msg.content}
                        </div>
                    </div>
                `;
            }
            const isUser = msg.role === 'user';
            return dateHeader + `
                <div class="message ${msg.role}" style="justify-content:${isUser ? 'flex-end' : 'flex-start'}">
                    ${!isUser ? '<div class="message-avatar" style="background:#1e2040">🦊</div>' : ''}
                    <div>
                        <div class="message-bubble" style="background:${isUser ? '#6c5ce7' : '#1e2040'};color:${isUser ? 'white' : '#e0e0e0'};max-width:100%;padding:0.75rem 1rem;border-radius:18px;${isUser ? 'border-bottom-right-radius:4px' : 'border-bottom-left-radius:4px'}">${msg.content}</div>
                        <div class="message-time" style="text-align:${isUser ? 'right' : 'left'}">${this.formatTime(msg.timestamp)}</div>
                    </div>
                    ${isUser ? '<div class="message-avatar" style="background:#6c5ce7;color:white">👤</div>' : ''}
                </div>
            `;
        }).join('');
    }

    addMessageToChat(message) {
        const chatMessages = document.getElementById('chat-messages');
        if (!chatMessages) return;
        
        const isUser = message.role === 'user';
        const messageEl = document.createElement('div');
        messageEl.className = `message ${message.role}`;
        messageEl.style.justifyContent = isUser ? 'flex-end' : 'flex-start';
        messageEl.innerHTML = `
            ${!isUser ? '<div class="message-avatar" style="background:#1e2040">🦊</div>' : ''}
            <div>
                <div class="message-bubble" style="background:${isUser ? '#6c5ce7' : '#1e2040'};color:${isUser ? 'white' : '#e0e0e0'};max-width:100%;padding:0.75rem 1rem;border-radius:18px;${isUser ? 'border-bottom-right-radius:4px' : 'border-bottom-left-radius:4px'}">${message.content}</div>
                <div class="message-time" style="text-align:${isUser ? 'right' : 'left'}">${this.formatTime(message.timestamp)}</div>
            </div>
            ${isUser ? '<div class="message-avatar" style="background:#6c5ce7;color:white">👤</div>' : ''}
        `;
        chatMessages.appendChild(messageEl);
    }

    async sendMessage() {
        const input = document.getElementById('chat-input');
        const content = input.value.trim();
        
        if (!content) return;
        
        // Show typing indicator
        const typingIndicator = document.getElementById('typing-indicator');
        
        try {
            input.disabled = true;
            input.value = '';
            input.style.height = 'auto';
            
            // Add user message immediately
            const tempUserMsg = { role: 'user', content, timestamp: new Date().toISOString() };
            this.addMessageToChat(tempUserMsg);
            this.scrollChatToBottom();
            
            // Show typing
            if (typingIndicator) typingIndicator.style.display = 'flex';
            
            const response = await fetch('/api/chat/send', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content })
            });
            
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();
            
            // Hide typing
            if (typingIndicator) typingIndicator.style.display = 'none';
            
            // Add assistant response (user msg already shown)
            this.addMessageToChat(data.assistant_message);
            
            this.allChatMessages.push(data.user_message);
            this.allChatMessages.push(data.assistant_message);
            
            this.scrollChatToBottom();
            
        } catch (error) {
            console.error('Error sending message:', error);
            if (typingIndicator) typingIndicator.style.display = 'none';
            this.showError('Failed to send message');
        } finally {
            input.disabled = false;
            input.focus();
        }
    }

    scrollChatToBottom() {
        const chatMessages = document.getElementById('chat-messages');
        if (chatMessages) {
            requestAnimationFrame(() => {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            });
        }
    }

    formatAction(action) {
        return action.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    }

    formatTime(timestamp) {
        try {
            return new Date(timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        } catch { return 'now'; }
    }

    formatDate(timestamp) {
        try {
            return new Date(timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        } catch { return 'today'; }
    }

    formatDateTime(timestamp) {
        try {
            return new Date(timestamp).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
        } catch { return 'now'; }
    }

    showError(message) {
        console.error(message);
        this.showToast(message, '#ff4757');
    }

    showSuccess(message) {
        this.showToast(message, '#28c840');
    }

    showToast(message, bg) {
        const toast = document.createElement('div');
        toast.textContent = message;
        toast.style.cssText = `position:fixed;top:20px;right:20px;background:${bg};color:white;padding:12px 20px;border-radius:8px;z-index:9999;font-size:0.9rem;box-shadow:0 4px 12px rgba(0,0,0,0.3);animation:slideIn 0.3s ease`;
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s';
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 3000);
    }

    autoResizeTextarea(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }

    async addQuickTask() {
        const input = document.getElementById('quick-task-input');
        const title = input.value.trim();
        
        if (!title) return;
        
        try {
            const response = await fetch('/api/tasks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title })
            });
            
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            
            input.value = '';
            this.showSuccess('Task added!');
            
            // Reload dashboard stats
            this.loadDashboardStats();
            
        } catch (error) {
            console.error('Error adding task:', error);
            this.showError('Failed to add task');
        }
    }

    filterChatMessages(query) {
        if (!query) {
            this.renderChatMessages(this.allChatMessages);
            return;
        }
        
        const filtered = this.allChatMessages.filter(msg => 
            msg.content.toLowerCase().includes(query.toLowerCase())
        );
        this.renderChatMessages(filtered);
    }

    handleFileSelection(event) {
        const files = Array.from(event.target.files);
        this.selectedFiles = files;
        
        const preview = document.getElementById('file-preview');
        if (!preview) return;
        
        if (files.length > 0) {
            preview.style.display = 'block';
            preview.innerHTML = files.map((f, i) => `
                <div class="file-preview-item">
                    <span class="file-name">${this.getFileIcon(f.type)} ${f.name} (${this.formatFileSize(f.size)})</span>
                    <button class="file-remove-btn" onclick="window.drewApp.removeFile(${i})">✕</button>
                </div>
            `).join('');
        } else {
            preview.style.display = 'none';
            preview.innerHTML = '';
        }
    }

    removeFile(index) {
        this.selectedFiles.splice(index, 1);
        const dt = new DataTransfer();
        this.selectedFiles.forEach(f => dt.items.add(f));
        document.getElementById('file-input').files = dt.files;
        this.handleFileSelection({ target: { files: dt.files } });
    }

    getFileIcon(mimeType) {
        if (mimeType.startsWith('image/')) return '🖼️';
        if (mimeType.startsWith('audio/')) return '🎵';
        if (mimeType.startsWith('video/')) return '🎬';
        if (mimeType.includes('pdf')) return '📄';
        if (mimeType.includes('json')) return '📋';
        return '📎';
    }

    formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / 1048576).toFixed(1) + ' MB';
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.drewApp = new DrewCommandCenter();
});
