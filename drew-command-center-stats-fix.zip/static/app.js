// Drew Command Center v6.0 — Real Stats Edition

class DrewCommandCenter {
    constructor() {
        this.currentPage = 'chat';
        this.allChatMessages = [];
        this.selectedFiles = [];
        this.taskFilter = 'all';
        this.activityFilter = 'all';
        this.usageData = null;
        this.hourlyData = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupMobileMenu();
        this.loadPage('chat');
        setInterval(() => {
            if (this.currentPage === 'dashboard') this.loadDashboardStats();
        }, 30000);
    }

    // ─── Formatting Helpers ───
    fmtMoney(n) { return '$' + n.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}); }
    fmtTokens(n) {
        if (n >= 1e9) return (n/1e9).toFixed(1) + 'B';
        if (n >= 1e6) return (n/1e6).toFixed(1) + 'M';
        if (n >= 1e3) return (n/1e3).toFixed(1) + 'K';
        return n.toString();
    }
    fmtPct(n) { return n.toFixed(1) + '%'; }

    familyColor(family) {
        const colors = {opus: '#6c5ce7', sonnet: '#3b82f6', haiku: '#22c55e'};
        return colors[family] || '#8b8fa3';
    }
    familyColorBg(family) {
        const colors = {opus: 'rgba(108,92,231,0.15)', sonnet: 'rgba(59,130,246,0.15)', haiku: 'rgba(34,197,94,0.15)'};
        return colors[family] || 'rgba(139,143,163,0.15)';
    }

    // ─── SVG Chart Builders ───
    buildLineChart(dailyData, width = 800, height = 250) {
        if (!dailyData || dailyData.length === 0) return '<p class="text-muted">No data</p>';
        
        const pad = {top: 30, right: 20, bottom: 50, left: 60};
        const w = width - pad.left - pad.right;
        const h = height - pad.top - pad.bottom;
        
        // Collect all model families across all days
        const familyTotals = {};
        dailyData.forEach(d => {
            Object.values(d.models || {}).forEach(m => {
                if (!familyTotals[m.family]) familyTotals[m.family] = new Array(dailyData.length).fill(0);
            });
        });
        const totalLine = dailyData.map(d => d.total_cost || 0);
        dailyData.forEach((d, i) => {
            Object.values(d.models || {}).forEach(m => {
                if (familyTotals[m.family]) familyTotals[m.family][i] += m.cost;
            });
        });
        
        const maxVal = Math.max(...totalLine, 0.01);
        const xStep = w / Math.max(dailyData.length - 1, 1);
        
        const makePath = (values, color, strokeWidth = 2) => {
            const points = values.map((v, i) => `${pad.left + i * xStep},${pad.top + h - (v / maxVal) * h}`);
            return `<polyline points="${points.join(' ')}" fill="none" stroke="${color}" stroke-width="${strokeWidth}" stroke-linejoin="round" stroke-linecap="round"/>`;
        };
        
        // Grid lines
        let gridLines = '';
        const gridSteps = 5;
        for (let i = 0; i <= gridSteps; i++) {
            const y = pad.top + (h / gridSteps) * i;
            const val = maxVal - (maxVal / gridSteps) * i;
            gridLines += `<line x1="${pad.left}" y1="${y}" x2="${pad.left + w}" y2="${y}" stroke="#1e2040" stroke-width="1"/>`;
            gridLines += `<text x="${pad.left - 8}" y="${y + 4}" fill="#8b8fa3" font-size="11" text-anchor="end">$${val.toFixed(val >= 10 ? 0 : 2)}</text>`;
        }
        
        // X-axis labels (show every Nth)
        let xLabels = '';
        const labelEvery = Math.max(1, Math.floor(dailyData.length / 8));
        dailyData.forEach((d, i) => {
            if (i % labelEvery === 0 || i === dailyData.length - 1) {
                const x = pad.left + i * xStep;
                const label = d.date.slice(5); // MM-DD
                xLabels += `<text x="${x}" y="${pad.top + h + 20}" fill="#8b8fa3" font-size="10" text-anchor="middle">${label}</text>`;
            }
        });
        
        // Hover dots and tooltip areas
        let hoverElements = '';
        dailyData.forEach((d, i) => {
            const x = pad.left + i * xStep;
            const y = pad.top + h - (d.total_cost / maxVal) * h;
            const modelBreakdown = Object.values(d.models || {}).map(m => `${m.display}: $${m.cost.toFixed(2)}`).join('\\n');
            hoverElements += `<circle cx="${x}" cy="${y}" r="4" fill="#febc2e" opacity="0" class="chart-dot" data-idx="${i}"><title>${d.date}\\nTotal: $${d.total_cost.toFixed(2)}\\n${modelBreakdown}</title></circle>`;
        });
        
        let paths = '';
        Object.entries(familyTotals).forEach(([family, values]) => {
            paths += makePath(values, this.familyColor(family), 1.5);
        });
        paths += makePath(totalLine, '#febc2e', 2.5);
        
        return `<svg viewBox="0 0 ${width} ${height}" style="width:100%;height:auto;max-height:${height}px">
            ${gridLines}${xLabels}${paths}${hoverElements}
            <style>.chart-dot:hover{opacity:1!important;r:6}</style>
        </svg>`;
    }

    buildBarChart(dailyData, width = 800, height = 220) {
        if (!dailyData || dailyData.length === 0) return '<p class="text-muted">No data</p>';
        
        const pad = {top: 20, right: 20, bottom: 50, left: 70};
        const w = width - pad.left - pad.right;
        const h = height - pad.top - pad.bottom;
        
        const maxVal = Math.max(...dailyData.map(d => (d.total_input || 0) + (d.total_output || 0)), 1);
        const barW = Math.max(4, (w / dailyData.length) - 2);
        
        let bars = '';
        let xLabels = '';
        const labelEvery = Math.max(1, Math.floor(dailyData.length / 8));
        
        dailyData.forEach((d, i) => {
            const x = pad.left + (w / dailyData.length) * i + 1;
            const inputH = ((d.total_input || 0) / maxVal) * h;
            const outputH = ((d.total_output || 0) / maxVal) * h;
            const totalH = inputH + outputH;
            const y = pad.top + h - totalH;
            
            bars += `<rect x="${x}" y="${y + outputH}" width="${barW}" height="${inputH}" fill="#3b82f6" rx="1"><title>${d.date}\nInput: ${this.fmtTokens(d.total_input)}\nOutput: ${this.fmtTokens(d.total_output)}</title></rect>`;
            bars += `<rect x="${x}" y="${y}" width="${barW}" height="${outputH}" fill="#f97316" rx="1"><title>${d.date}\nOutput: ${this.fmtTokens(d.total_output)}</title></rect>`;
            
            if (i % labelEvery === 0 || i === dailyData.length - 1) {
                xLabels += `<text x="${x + barW/2}" y="${pad.top + h + 20}" fill="#8b8fa3" font-size="10" text-anchor="middle">${d.date.slice(5)}</text>`;
            }
        });
        
        // Y-axis
        let yLabels = '';
        for (let i = 0; i <= 4; i++) {
            const y = pad.top + (h / 4) * i;
            const val = maxVal - (maxVal / 4) * i;
            yLabels += `<line x1="${pad.left}" y1="${y}" x2="${pad.left + w}" y2="${y}" stroke="#1e2040" stroke-width="1"/>`;
            yLabels += `<text x="${pad.left - 8}" y="${y + 4}" fill="#8b8fa3" font-size="11" text-anchor="end">${this.fmtTokens(val)}</text>`;
        }
        
        return `<svg viewBox="0 0 ${width} ${height}" style="width:100%;height:auto;max-height:${height}px">
            ${yLabels}${bars}${xLabels}
        </svg>
        <div style="display:flex;gap:1.5rem;justify-content:center;margin-top:0.5rem;font-size:0.8rem">
            <span><span style="display:inline-block;width:12px;height:12px;background:#3b82f6;border-radius:2px;margin-right:4px;vertical-align:middle"></span>Input Tokens</span>
            <span><span style="display:inline-block;width:12px;height:12px;background:#f97316;border-radius:2px;margin-right:4px;vertical-align:middle"></span>Output Tokens</span>
        </div>`;
    }

    buildDonutChart(modelSummary, size = 200) {
        if (!modelSummary || Object.keys(modelSummary).length === 0) return '';
        
        // Aggregate by family
        const families = {};
        Object.values(modelSummary).forEach(m => {
            if (!families[m.family]) families[m.family] = 0;
            families[m.family] += m.cost;
        });
        
        const total = Object.values(families).reduce((a, b) => a + b, 0) || 1;
        const r = size / 2 - 10;
        const cx = size / 2, cy = size / 2;
        let startAngle = -Math.PI / 2;
        let paths = '';
        
        Object.entries(families).sort((a, b) => b[1] - a[1]).forEach(([family, cost]) => {
            const pct = cost / total;
            const endAngle = startAngle + pct * 2 * Math.PI;
            const largeArc = pct > 0.5 ? 1 : 0;
            const x1 = cx + r * Math.cos(startAngle), y1 = cy + r * Math.sin(startAngle);
            const x2 = cx + r * Math.cos(endAngle), y2 = cy + r * Math.sin(endAngle);
            
            paths += `<path d="M${cx},${cy} L${x1},${y1} A${r},${r} 0 ${largeArc},1 ${x2},${y2} Z" fill="${this.familyColor(family)}"><title>${family}: ${this.fmtMoney(cost)} (${this.fmtPct(pct * 100)})</title></path>`;
            startAngle = endAngle;
        });
        
        return `<svg viewBox="0 0 ${size} ${size}" style="width:${size}px;height:${size}px">
            ${paths}
            <circle cx="${cx}" cy="${cy}" r="${r * 0.55}" fill="#12122a"/>
            <text x="${cx}" y="${cy - 8}" fill="#e0e0e0" font-size="16" font-weight="700" text-anchor="middle">${this.fmtMoney(total)}</text>
            <text x="${cx}" y="${cy + 12}" fill="#8b8fa3" font-size="10" text-anchor="middle">Total Spend</text>
        </svg>
        <div style="display:flex;flex-direction:column;gap:0.5rem;margin-top:1rem">
            ${Object.entries(families).sort((a, b) => b[1] - a[1]).map(([f, c]) => 
                `<div style="display:flex;align-items:center;gap:0.5rem"><span style="width:12px;height:12px;border-radius:3px;background:${this.familyColor(f)}"></span><span style="color:#e0e0e0;text-transform:capitalize;font-weight:600">${f}</span><span style="color:#8b8fa3;margin-left:auto">${this.fmtMoney(c)} (${this.fmtPct(c/total*100)})</span></div>`
            ).join('')}
        </div>`;
    }

    buildHeatmap(hourlyData) {
        if (!hourlyData || hourlyData.length === 0) return '<p class="text-muted">No hourly data available</p>';
        
        // Organize by day-of-week and hour
        const grid = {}; // "dow-hour" -> total_tokens
        let maxTokens = 1;
        hourlyData.forEach(h => {
            const dt = new Date(h.starting_at);
            const dow = dt.getUTCDay();
            const hour = dt.getUTCHours();
            const key = `${dow}-${hour}`;
            grid[key] = (grid[key] || 0) + h.total_tokens;
            if (grid[key] > maxTokens) maxTokens = grid[key];
        });
        
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const cellW = 28, cellH = 24, padL = 40, padT = 25;
        const width = padL + 24 * cellW + 10;
        const height = padT + 7 * cellH + 10;
        
        let cells = '';
        for (let dow = 0; dow < 7; dow++) {
            cells += `<text x="${padL - 5}" y="${padT + dow * cellH + cellH/2 + 4}" fill="#8b8fa3" font-size="10" text-anchor="end">${days[dow]}</text>`;
            for (let hr = 0; hr < 24; hr++) {
                const val = grid[`${dow}-${hr}`] || 0;
                const intensity = val / maxTokens;
                const alpha = Math.max(0.05, intensity);
                cells += `<rect x="${padL + hr * cellW}" y="${padT + dow * cellH}" width="${cellW - 2}" height="${cellH - 2}" rx="3" fill="rgba(108,92,231,${alpha})"><title>${days[dow]} ${hr}:00 — ${this.fmtTokens(val)} tokens</title></rect>`;
            }
        }
        // Hour labels
        let hourLabels = '';
        for (let hr = 0; hr < 24; hr += 3) {
            hourLabels += `<text x="${padL + hr * cellW + cellW/2}" y="${padT - 8}" fill="#8b8fa3" font-size="9" text-anchor="middle">${hr}:00</text>`;
        }
        
        return `<svg viewBox="0 0 ${width} ${height}" style="width:100%;height:auto;max-height:${height}px;overflow:visible">
            ${hourLabels}${cells}
        </svg>`;
    }

    buildSparkline(values, width = 120, height = 30, color = '#febc2e') {
        if (!values || values.length < 2) return '';
        const max = Math.max(...values, 0.01);
        const min = Math.min(...values, 0);
        const range = max - min || 1;
        const step = width / (values.length - 1);
        const points = values.map((v, i) => `${i * step},${height - ((v - min) / range) * (height - 4) - 2}`).join(' ');
        return `<svg viewBox="0 0 ${width} ${height}" style="width:${width}px;height:${height}px"><polyline points="${points}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round"/></svg>`;
    }

    // ─── Stats Page ───
    async loadDetailedStats() {
        const container = document.getElementById('stats-content');
        if (!container) return;
        
        container.innerHTML = '<div style="text-align:center;padding:3rem"><div class="loading" style="width:40px;height:40px;margin:0 auto"></div><p class="text-muted" style="margin-top:1rem">Loading real usage data...</p></div>';
        
        try {
            const [usageRes, hourlyRes] = await Promise.all([
                fetch('/api/anthropic/usage'),
                fetch('/api/anthropic/usage/hourly')
            ]);
            
            const usage = await usageRes.json();
            const hourly = await hourlyRes.json();
            
            if (!usage.configured) {
                container.innerHTML = `
                    <div class="card" style="text-align:center;padding:3rem;border-color:#febc2e">
                        <div style="font-size:3rem;margin-bottom:1rem">🔑</div>
                        <h2 style="color:#febc2e;margin-bottom:1rem">Configure ANTHROPIC_ADMIN_KEY to see real usage data</h2>
                        <p class="text-muted" style="max-width:500px;margin:0 auto">Set the <code style="background:#1e2040;padding:0.2rem 0.5rem;border-radius:4px">ANTHROPIC_ADMIN_KEY</code> environment variable on your Elastic Beanstalk environment to enable real-time Anthropic API usage tracking.</p>
                        <pre style="background:#0a0a1a;padding:1rem;border-radius:8px;margin-top:1.5rem;text-align:left;font-size:0.8rem;overflow-x:auto;color:#8b8fa3">aws elasticbeanstalk update-environment \\
  --environment-name Drew-command-center-env \\
  --option-settings "Namespace=aws:elasticbeanstalk:application:environment,OptionName=ANTHROPIC_ADMIN_KEY,Value=YOUR_KEY_HERE" \\
  --region eu-west-2</pre>
                    </div>`;
                return;
            }
            
            if (usage.error) {
                container.innerHTML = `<div class="card" style="border-color:#ff5f57"><h3 style="color:#ff5f57">⚠️ Error fetching usage data</h3><p class="text-muted">${usage.error}</p></div>`;
                return;
            }
            
            this.usageData = usage;
            this.hourlyData = hourly;
            this.renderStatsPage(usage, hourly);
            
        } catch (error) {
            console.error('Stats error:', error);
            container.innerHTML = `<div class="card" style="border-color:#ff5f57"><h3 style="color:#ff5f57">⚠️ Failed to load stats</h3><p class="text-muted">${error.message}</p></div>`;
        }
    }

    renderStatsPage(usage, hourly) {
        const container = document.getElementById('stats-content');
        const t = usage.totals || {};
        const totalTokens = (t.input_tokens || 0) + (t.output_tokens || 0);
        const cacheRate = t.input_tokens > 0 ? ((t.cache_read_tokens || 0) / t.input_tokens * 100) : 0;
        const costPerKTok = totalTokens > 0 ? (t.cost / (totalTokens / 1000)) : 0;
        const tokensPerDollar = t.cost > 0 ? (totalTokens / t.cost) : 0;
        const avgCostPerRequest = t.buckets > 0 ? (t.cost / t.buckets) : 0;
        
        container.innerHTML = `
            <!-- KPI Tiles -->
            <div class="kpi-row">
                <div class="kpi-tile" style="border-top:3px solid #6c5ce7">
                    <div class="kpi-value" style="color:#6c5ce7">${this.fmtMoney(t.cost || 0)}</div>
                    <div class="kpi-label">Total Spend (30d)</div>
                </div>
                <div class="kpi-tile" style="border-top:3px solid #febc2e">
                    <div class="kpi-value" style="color:#febc2e">${this.fmtMoney(usage.month_cost || 0)}</div>
                    <div class="kpi-label">This Month</div>
                </div>
                <div class="kpi-tile" style="border-top:3px solid #22c55e">
                    <div class="kpi-value" style="color:#22c55e">${this.fmtMoney(usage.today_cost || 0)}</div>
                    <div class="kpi-label">Today</div>
                </div>
                <div class="kpi-tile" style="border-top:3px solid #3b82f6">
                    <div class="kpi-value" style="color:#3b82f6">${this.fmtTokens(totalTokens)}</div>
                    <div class="kpi-label">Total Tokens</div>
                </div>
                <div class="kpi-tile" style="border-top:3px solid #f97316">
                    <div class="kpi-value" style="color:#f97316">${t.buckets || 0}</div>
                    <div class="kpi-label">API Calls</div>
                </div>
            </div>
            
            <!-- Daily Spend Line Chart -->
            <div class="card chart-card">
                <div class="card-header">
                    <h2>📈 Daily Spend (Last 30 Days)</h2>
                    <div style="display:flex;gap:1rem;font-size:0.8rem">
                        <span><span style="display:inline-block;width:12px;height:3px;background:#6c5ce7;margin-right:4px;vertical-align:middle"></span>Opus</span>
                        <span><span style="display:inline-block;width:12px;height:3px;background:#3b82f6;margin-right:4px;vertical-align:middle"></span>Sonnet</span>
                        <span><span style="display:inline-block;width:12px;height:3px;background:#22c55e;margin-right:4px;vertical-align:middle"></span>Haiku</span>
                        <span><span style="display:inline-block;width:12px;height:3px;background:#febc2e;margin-right:4px;vertical-align:middle"></span>Total</span>
                    </div>
                </div>
                <div class="chart-container">${this.buildLineChart(usage.daily_data)}</div>
            </div>
            
            <!-- Model Breakdown + Donut -->
            <div style="display:grid;grid-template-columns:250px 1fr;gap:1.5rem;margin-bottom:1.5rem" class="model-breakdown-grid">
                <div class="card" style="display:flex;flex-direction:column;align-items:center;justify-content:center">
                    <h3 style="margin-bottom:1rem;font-size:1rem;color:#8b8fa3">Spend by Family</h3>
                    ${this.buildDonutChart(usage.model_summary)}
                </div>
                <div class="card">
                    <h3 style="margin-bottom:1rem">Model Breakdown</h3>
                    <table class="cost-table">
                        <thead><tr>
                            <th>Model</th><th style="text-align:right">Input</th><th style="text-align:right">Output</th><th style="text-align:right">Cache Read</th><th style="text-align:right">Cost</th><th style="text-align:right">%</th>
                        </tr></thead>
                        <tbody>
                            ${Object.entries(usage.model_summary || {}).sort((a,b) => b[1].cost - a[1].cost).map(([id, m]) => {
                                const pct = t.cost > 0 ? (m.cost / t.cost * 100) : 0;
                                return `<tr>
                                    <td style="color:${this.familyColor(m.family)};font-weight:600">${m.display}</td>
                                    <td style="text-align:right">${this.fmtTokens(m.input_tokens)}</td>
                                    <td style="text-align:right">${this.fmtTokens(m.output_tokens)}</td>
                                    <td style="text-align:right">${this.fmtTokens(m.cache_read_tokens)}</td>
                                    <td style="text-align:right;font-weight:600">${this.fmtMoney(m.cost)}</td>
                                    <td style="text-align:right">${this.fmtPct(pct)}</td>
                                </tr>`;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Daily Token Usage Bar Chart -->
            <div class="card chart-card">
                <div class="card-header"><h2>📊 Daily Token Usage</h2></div>
                <div class="chart-container">${this.buildBarChart(usage.daily_data)}</div>
            </div>
            
            <!-- Cost Efficiency Tiles -->
            <div class="kpi-row" style="margin-bottom:1.5rem">
                <div class="kpi-tile">
                    <div class="kpi-value" style="color:#a78bfa;font-size:1.5rem">${this.fmtMoney(avgCostPerRequest)}</div>
                    <div class="kpi-label">Avg Cost / Request</div>
                </div>
                <div class="kpi-tile">
                    <div class="kpi-value" style="color:#60a5fa;font-size:1.5rem">${costPerKTok.toFixed(4)}</div>
                    <div class="kpi-label">Cost per 1K Tokens</div>
                </div>
                <div class="kpi-tile">
                    <div class="kpi-value" style="color:#34d399;font-size:1.5rem">${this.fmtPct(cacheRate)}</div>
                    <div class="kpi-label">Cache Hit Rate</div>
                </div>
                <div class="kpi-tile">
                    <div class="kpi-value" style="color:#fbbf24;font-size:1.5rem">${this.fmtTokens(tokensPerDollar)}</div>
                    <div class="kpi-label">Tokens per Dollar</div>
                </div>
            </div>
            
            <!-- Hourly Activity Heatmap -->
            <div class="card chart-card">
                <div class="card-header"><h2>🔥 Activity Heatmap (Last 7 Days, UTC)</h2></div>
                <div class="chart-container" style="overflow-x:auto">${this.buildHeatmap(hourly.hourly_data)}</div>
            </div>
        `;
        
        // Animate KPI values
        container.querySelectorAll('.kpi-tile').forEach((el, i) => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            setTimeout(() => {
                el.style.transition = 'all 0.4s ease';
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, i * 80);
        });
    }

    // ─── Models Page ───
    async loadModels() {
        const modelsGrid = document.getElementById('models-grid');
        const costSavings = document.getElementById('cost-savings-content');
        const currentModel = document.getElementById('current-model-display');
        
        try {
            const response = await fetch('/api/models');
            const data = await response.json();
            
            if (!data.configured) {
                if (modelsGrid) modelsGrid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:2rem"><p class="text-muted">Configure ANTHROPIC_ADMIN_KEY to see real model usage data</p></div>';
                return;
            }
            
            const models = data.model_summary || {};
            const sorted = Object.entries(models).sort((a, b) => b[1].cost - a[1].cost);
            
            if (costSavings) {
                costSavings.innerHTML = `
                    <div class="cost-savings-grid">
                        <div class="cost-comparison-item current">
                            <div class="cost-amount current">${this.fmtMoney(data.today_cost || 0)}</div>
                            <div class="cost-label">Today's Spend</div>
                        </div>
                        <div class="cost-comparison-item alternative">
                            <div class="cost-amount alternative">${this.fmtMoney(data.month_cost || 0)}</div>
                            <div class="cost-label">Month to Date</div>
                        </div>
                        <div class="cost-comparison-item savings">
                            <div class="cost-amount savings">${this.fmtMoney(data.total_cost || 0)}</div>
                            <div class="cost-label">All Time (30d)</div>
                        </div>
                    </div>`;
            }
            
            if (currentModel && sorted.length > 0) {
                const [topId, topModel] = sorted[0];
                currentModel.innerHTML = `
                    <div class="current-model-display">
                        <div style="font-size:2rem;color:${this.familyColor(topModel.family)}">●</div>
                        <div class="current-model-info">
                            <div class="current-model-name">${topModel.display}</div>
                            <div class="current-model-desc">Highest usage model (${this.fmtMoney(topModel.cost)})</div>
                        </div>
                    </div>`;
            }
            
            if (modelsGrid) {
                modelsGrid.innerHTML = sorted.map(([id, m]) => {
                    const totalTok = (m.input_tokens || 0) + (m.output_tokens || 0);
                    const p = m.pricing || {};
                    return `
                    <div class="model-card" style="border-color:${this.familyColor(m.family)}33">
                        <div class="model-header">
                            <div class="model-title">
                                <span style="font-size:1.5rem;color:${this.familyColor(m.family)}">●</span>
                                <h4>${m.display}</h4>
                            </div>
                            <span class="model-badge" style="background:${this.familyColorBg(m.family)};color:${this.familyColor(m.family)}">${m.family}</span>
                        </div>
                        <div class="model-pricing">
                            <div class="pricing-grid">
                                <div class="pricing-item"><span>Total Spend</span><span class="price" style="color:${this.familyColor(m.family)}">${this.fmtMoney(m.cost)}</span></div>
                                <div class="pricing-item"><span>Total Tokens</span><span class="price">${this.fmtTokens(totalTok)}</span></div>
                                <div class="pricing-item"><span>Input</span><span class="price">${this.fmtTokens(m.input_tokens)}</span></div>
                                <div class="pricing-item"><span>Output</span><span class="price">${this.fmtTokens(m.output_tokens)}</span></div>
                                <div class="pricing-item"><span>Cache Read</span><span class="price">${this.fmtTokens(m.cache_read_tokens)}</span></div>
                                <div class="pricing-item"><span>Days Active</span><span class="price">${m.days_active}</span></div>
                            </div>
                            ${p.input ? `<div style="margin-top:0.75rem;padding-top:0.75rem;border-top:1px solid #1e2040;font-size:0.8rem;color:#8b8fa3">
                                Pricing: $${p.input}/MTok in · $${p.output}/MTok out${p.cache_read ? ` · $${p.cache_read}/MTok cache` : ''}
                            </div>` : ''}
                        </div>
                    </div>`;
                }).join('');
            }
        } catch (error) {
            console.error('Error loading models:', error);
            if (modelsGrid) modelsGrid.innerHTML = '<div style="grid-column:1/-1"><p class="text-muted">Failed to load model data</p></div>';
        }
    }

    // ─── Dashboard with API cost tile ───
    async loadDashboardStats() {
        try {
            const response = await fetch('/api/stats');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const stats = await response.json();

            const setEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
            setEl('active-tasks-count', stats.active_tasks || 0);
            setEl('completed-today-count', stats.completed_today || 0);
            setEl('scheduled-jobs-count', stats.scheduled_jobs || 0);
            setEl('messages-today-count', stats.messages_today || 0);
            
            // Load API cost tile
            try {
                const usageRes = await fetch('/api/anthropic/usage');
                const usage = await usageRes.json();
                if (usage.configured && !usage.error) {
                    const costTile = document.getElementById('api-cost-tile');
                    if (costTile) {
                        const last7 = (usage.daily_data || []).slice(-7).map(d => d.total_cost);
                        costTile.innerHTML = `
                            <div class="stat-value" style="color:#febc2e;font-size:1.6rem">${this.fmtMoney(usage.today_cost || 0)}</div>
                            <div class="stat-label">Today's API Cost</div>
                            <div style="margin-top:0.5rem;font-size:0.8rem;color:#8b8fa3">Month: ${this.fmtMoney(usage.month_cost || 0)}</div>
                            <div style="margin-top:0.25rem">${this.buildSparkline(last7)}</div>
                        `;
                    }
                }
            } catch (e) { /* API cost tile optional */ }
            
        } catch (error) {
            console.error('Error loading dashboard stats:', error);
        }
    }

    // ─── All existing methods below (kept intact) ───
    setupEventListeners() {
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => { e.preventDefault(); this.loadPage(item.dataset.page); });
        });
        const chatForm = document.getElementById('chat-form');
        if (chatForm) chatForm.addEventListener('submit', (e) => { e.preventDefault(); this.sendMessage(); });
        const quickTaskForm = document.getElementById('quick-task-form');
        if (quickTaskForm) quickTaskForm.addEventListener('submit', (e) => { e.preventDefault(); this.addQuickTask(); });
        const chatInput = document.getElementById('chat-input');
        if (chatInput) {
            chatInput.addEventListener('input', () => this.autoResizeTextarea(chatInput));
            chatInput.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this.sendMessage(); } });
        }
        const chatSearch = document.getElementById('chat-search');
        if (chatSearch) chatSearch.addEventListener('input', (e) => this.filterChatMessages(e.target.value));
        const fileInput = document.getElementById('file-input');
        if (fileInput) fileInput.addEventListener('change', (e) => this.handleFileSelection(e));
    }

    setupMobileMenu() {
        const menuToggle = document.getElementById('mobile-menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', () => sidebar.classList.toggle('mobile-visible'));
            document.addEventListener('click', (e) => {
                if (!sidebar.contains(e.target) && !menuToggle.contains(e.target)) sidebar.classList.remove('mobile-visible');
            });
        }
    }

    loadPage(page) {
        document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
        const navItem = document.querySelector(`[data-page="${page}"]`);
        if (navItem) navItem.classList.add('active');
        document.querySelectorAll('[id$="-page"]').forEach(p => p.classList.add('d-none'));
        const pageEl = document.getElementById(`${page}-page`);
        if (pageEl) pageEl.classList.remove('d-none');
        this.currentPage = page;
        this.loadPageData(page);
        document.querySelector('.sidebar')?.classList.remove('mobile-visible');
    }

    async loadPageData(page) {
        try {
            switch(page) {
                case 'dashboard': await this.loadDashboardStats(); await this.loadRecentActivity(); break;
                case 'chat': await this.loadChat(); break;
                case 'tasks': await this.loadTasks(); break;
                case 'scheduled': await this.loadScheduledJobs(); break;
                case 'activity': await this.loadActivity(); break;
                case 'stats': await this.loadDetailedStats(); break;
                case 'models': await this.loadModels(); break;
            }
        } catch (error) { console.error(`Error loading ${page}:`, error); }
    }

    async loadRecentActivity() {
        try {
            const response = await fetch('/api/activity?limit=10');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const activities = await response.json();
            const activityList = document.getElementById('recent-activity');
            if (!activityList) return;
            if (activities && activities.length > 0) {
                activityList.innerHTML = activities.map(a => `<div class="activity-item"><div class="activity-time">${this.formatDateTime(a.timestamp)}</div><div class="activity-content"><h4>${this.formatAction(a.action)}</h4><p>${a.summary}</p></div></div>`).join('');
            } else {
                activityList.innerHTML = '<div class="activity-item"><div class="activity-content"><p class="text-muted">No recent activity</p></div></div>';
            }
        } catch (error) { console.error('Error loading recent activity:', error); }
    }

    async loadTasks() {
        try {
            const response = await fetch('/api/tasks');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const tasks = await response.json();
            this.allTasks = tasks;
            this.renderTasks(tasks);
            this.setupTaskFilters();
        } catch (error) { console.error('Error loading tasks:', error); }
    }

    renderTasks(tasks) {
        const filtered = this.taskFilter === 'all' ? tasks : tasks.filter(t => t.status === this.taskFilter);
        const tasksList = document.getElementById('tasks-list');
        if (!tasksList) return;
        if (filtered && filtered.length > 0) {
            tasksList.innerHTML = filtered.map(task => `
                <div class="task-item" data-task-id="${task.id}">
                    <div class="task-title">${task.title}</div>
                    <div class="text-muted" style="font-size:0.85rem;margin:0.25rem 0">${task.description || ''}</div>
                    ${task.progress !== undefined ? `<div style="background:#1e2040;border-radius:4px;height:6px;margin:0.5rem 0;overflow:hidden"><div style="background:${task.progress === 100 ? '#28c840' : '#6c5ce7'};height:100%;width:${task.progress}%;border-radius:4px;transition:width 0.3s"></div></div>` : ''}
                    <div class="task-meta"><span class="task-status status-${task.status}">${task.status}</span><span class="priority-${task.priority}">${task.priority}</span><span class="text-muted">${task.category || 'general'}</span><span class="text-muted">${this.formatDate(task.created_at)}</span></div>
                </div>`).join('');
        } else { tasksList.innerHTML = '<div class="task-item"><div class="task-title text-muted">No tasks found</div></div>'; }
    }

    setupTaskFilters() {
        const header = document.querySelector('#tasks-page .card-header .d-flex');
        if (!header) return;
        const filters = ['all', 'queued', 'active', 'completed'];
        header.innerHTML = filters.map(f => `<button class="btn btn-secondary task-filter-btn ${this.taskFilter === f ? 'active' : ''}" data-filter="${f}" style="${this.taskFilter === f ? 'background:#6c5ce7;color:white' : ''}">${f.charAt(0).toUpperCase() + f.slice(1)}</button>`).join('');
        header.querySelectorAll('.task-filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.taskFilter = btn.dataset.filter;
                header.querySelectorAll('.task-filter-btn').forEach(b => { b.style.background = ''; b.style.color = ''; });
                btn.style.background = '#6c5ce7'; btn.style.color = 'white';
                this.renderTasks(this.allTasks || []);
            });
        });
    }

    async loadScheduledJobs() {
        try {
            const response = await fetch('/api/scheduled');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const jobs = await response.json();
            const jobsList = document.getElementById('scheduled-list');
            if (!jobsList) return;
            if (jobs && jobs.length > 0) {
                jobsList.innerHTML = jobs.map(job => `
                    <div class="card"><div class="d-flex justify-content-between align-items-center"><div><h3 style="margin-bottom:0.25rem">${job.name}</h3><p class="text-muted" style="margin-bottom:0.25rem">${job.description || ''}</p><p class="text-muted" style="font-size:0.85rem"><code style="background:#1e2040;padding:0.15rem 0.5rem;border-radius:4px">${job.schedule}</code> • Type: ${job.job_type || 'unknown'}</p></div><div style="text-align:right"><div class="status-indicator status-${job.status}"><div class="status-dot"></div>${job.status}</div>${job.next_run ? `<div class="text-muted mt-1" style="font-size:0.8rem">Next: ${this.formatDateTime(job.next_run)}</div>` : ''}${job.last_run ? `<div class="text-muted" style="font-size:0.8rem">Last: ${this.formatDateTime(job.last_run)} (${job.last_status || ''})</div>` : ''}</div></div></div>`).join('');
            } else { jobsList.innerHTML = '<div class="card"><p class="text-muted">No scheduled jobs</p></div>'; }
        } catch (error) { console.error('Error loading scheduled jobs:', error); }
    }

    async loadActivity() {
        try {
            const response = await fetch('/api/activity?limit=50');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const activities = await response.json();
            this.allActivities = activities;
            this.renderActivity(activities);
            this.setupActivityFilters();
        } catch (error) { console.error('Error loading activity:', error); }
    }

    renderActivity(activities) {
        const activityList = document.getElementById('activity-list');
        if (!activityList) return;
        const filtered = this.activityFilter === 'all' ? activities : activities.filter(a => {
            if (this.activityFilter === 'tasks') return a.action.includes('task');
            if (this.activityFilter === 'chat') return a.action.includes('chat');
            if (this.activityFilter === 'cron') return a.session_type === 'monitoring' || a.action.includes('scheduled');
            return true;
        });
        if (filtered && filtered.length > 0) {
            activityList.innerHTML = filtered.map(a => `<div class="activity-item"><div class="activity-time">${this.formatDateTime(a.timestamp)}</div><div class="activity-content"><h4>${this.formatAction(a.action)}</h4><p>${a.summary}</p><p class="text-muted" style="font-size:0.75rem">${a.session_type || 'unknown'} • ${a.user || 'system'}</p></div></div>`).join('');
        } else { activityList.innerHTML = '<div class="activity-item"><div class="activity-content"><p class="text-muted">No activity found</p></div></div>'; }
    }

    setupActivityFilters() {
        const filterContainer = document.querySelector('#activity-page > .d-flex .d-flex');
        if (!filterContainer) return;
        const filters = ['all', 'tasks', 'chat', 'cron'];
        filterContainer.innerHTML = filters.map(f => `<button class="btn btn-secondary activity-filter-btn" data-filter="${f}" style="${this.activityFilter === f ? 'background:#6c5ce7;color:white' : ''}">${f.charAt(0).toUpperCase() + f.slice(1)}</button>`).join('');
        filterContainer.querySelectorAll('.activity-filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.activityFilter = btn.dataset.filter;
                filterContainer.querySelectorAll('.activity-filter-btn').forEach(b => { b.style.background = ''; b.style.color = ''; });
                btn.style.background = '#6c5ce7'; btn.style.color = 'white';
                this.renderActivity(this.allActivities || []);
            });
        });
    }

    async loadChat() {
        try {
            const response = await fetch('/api/chat/live?limit=50');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();
            if (data.messages) {
                this.allChatMessages = data.messages;
                this.renderChatMessages(data.messages);
                this.scrollChatToBottom();
            }
        } catch (error) { console.error('Error loading chat:', error); }
    }

    renderChatMessages(messages) {
        const chatMessages = document.getElementById('chat-messages');
        if (!chatMessages) return;
        let lastDate = '';
        chatMessages.innerHTML = messages.map(msg => {
            let dateHeader = '';
            const msgDate = msg.session_date || (msg.timestamp ? msg.timestamp.substring(0, 10) : '');
            if (msgDate && msgDate !== lastDate) {
                lastDate = msgDate;
                const dateObj = new Date(msgDate + 'T12:00:00');
                const label = dateObj.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
                dateHeader = `<div style="text-align:center;margin:1.5rem 0 1rem"><div style="display:inline-block;background:#1a1a35;color:#6c5ce7;padding:0.4rem 1.2rem;border-radius:20px;font-size:0.8rem;font-weight:600;border:1px solid #2a2d5a">${label}</div></div>`;
            }
            if (msg.role === 'system') {
                return dateHeader + `<div style="text-align:center;margin:1rem 0"><div style="display:inline-block;background:#1e2040;color:#8b8fa3;padding:0.5rem 1rem;border-radius:20px;font-size:0.85rem">${msg.content}</div></div>`;
            }
            const isUser = msg.role === 'user';
            return dateHeader + `
                <div class="message ${msg.role}" style="justify-content:${isUser ? 'flex-end' : 'flex-start'}">
                    ${!isUser ? '<div class="message-avatar" style="background:#1e2040">🦊</div>' : ''}
                    <div>
                        <div class="message-bubble" style="background:${isUser ? '#6c5ce7' : '#1e2040'};color:${isUser ? 'white' : '#e0e0e0'};max-width:100%;padding:0.75rem 1rem;border-radius:18px;${isUser ? 'border-bottom-right-radius:4px' : 'border-bottom-left-radius:4px'}">${msg.content}</div>
                        <div class="message-time" style="text-align:${isUser ? 'right' : 'left'}">${this.formatTime(msg.timestamp)}</div>
                    </div>
                    ${isUser ? '<div class="message-avatar" style="background:#6c5ce7;color:white">👤</div>' : ''}
                </div>`;
        }).join('');
    }

    addMessageToChat(message) {
        const chatMessages = document.getElementById('chat-messages');
        if (!chatMessages) return;
        const isUser = message.role === 'user';
        const messageEl = document.createElement('div');
        messageEl.className = `message ${message.role}`;
        messageEl.style.justifyContent = isUser ? 'flex-end' : 'flex-start';
        messageEl.innerHTML = `
            ${!isUser ? '<div class="message-avatar" style="background:#1e2040">🦊</div>' : ''}
            <div>
                <div class="message-bubble" style="background:${isUser ? '#6c5ce7' : '#1e2040'};color:${isUser ? 'white' : '#e0e0e0'};max-width:100%;padding:0.75rem 1rem;border-radius:18px;${isUser ? 'border-bottom-right-radius:4px' : 'border-bottom-left-radius:4px'}">${message.content}</div>
                <div class="message-time" style="text-align:${isUser ? 'right' : 'left'}">${this.formatTime(message.timestamp)}</div>
            </div>
            ${isUser ? '<div class="message-avatar" style="background:#6c5ce7;color:white">👤</div>' : ''}`;
        chatMessages.appendChild(messageEl);
    }

    async sendMessage() {
        const input = document.getElementById('chat-input');
        const content = input.value.trim();
        if (!content) return;
        const typingIndicator = document.getElementById('typing-indicator');
        try {
            input.disabled = true; input.value = ''; input.style.height = 'auto';
            this.addMessageToChat({ role: 'user', content, timestamp: new Date().toISOString() });
            this.scrollChatToBottom();
            if (typingIndicator) typingIndicator.style.display = 'flex';
            const response = await fetch('/api/chat/send', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content }) });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();
            if (typingIndicator) typingIndicator.style.display = 'none';
            this.addMessageToChat(data.assistant_message);
            this.allChatMessages.push(data.user_message);
            this.allChatMessages.push(data.assistant_message);
            this.scrollChatToBottom();
        } catch (error) {
            console.error('Error sending message:', error);
            if (typingIndicator) typingIndicator.style.display = 'none';
        } finally { input.disabled = false; input.focus(); }
    }

    scrollChatToBottom() { const el = document.getElementById('chat-messages'); if (el) requestAnimationFrame(() => el.scrollTop = el.scrollHeight); }
    formatAction(action) { return action.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()); }
    formatTime(ts) { try { return new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }); } catch { return 'now'; } }
    formatDate(ts) { try { return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); } catch { return 'today'; } }
    formatDateTime(ts) { try { return new Date(ts).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return 'now'; } }
    showError(msg) { this.showToast(msg, '#ff4757'); }
    showSuccess(msg) { this.showToast(msg, '#28c840'); }
    showToast(message, bg) {
        const toast = document.createElement('div');
        toast.textContent = message;
        toast.style.cssText = `position:fixed;top:20px;right:20px;background:${bg};color:white;padding:12px 20px;border-radius:8px;z-index:9999;font-size:0.9rem;box-shadow:0 4px 12px rgba(0,0,0,0.3)`;
        document.body.appendChild(toast);
        setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.3s'; setTimeout(() => document.body.removeChild(toast), 300); }, 3000);
    }
    autoResizeTextarea(textarea) { textarea.style.height = 'auto'; textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px'; }
    async addQuickTask() {
        const input = document.getElementById('quick-task-input');
        const title = input.value.trim();
        if (!title) return;
        try {
            const response = await fetch('/api/tasks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title }) });
            if (!response.ok) throw new Error();
            input.value = ''; this.showSuccess('Task added!'); this.loadDashboardStats();
        } catch { this.showError('Failed to add task'); }
    }
    filterChatMessages(query) {
        if (!query) { this.renderChatMessages(this.allChatMessages); return; }
        this.renderChatMessages(this.allChatMessages.filter(msg => msg.content.toLowerCase().includes(query.toLowerCase())));
    }
    handleFileSelection(event) {
        const files = Array.from(event.target.files);
        this.selectedFiles = files;
        const preview = document.getElementById('file-preview');
        if (!preview) return;
        if (files.length > 0) {
            preview.style.display = 'block';
            preview.innerHTML = files.map((f, i) => `<div class="file-preview-item"><span class="file-name">${f.name} (${(f.size/1024).toFixed(1)} KB)</span><button class="file-remove-btn" onclick="window.drewApp.removeFile(${i})">✕</button></div>`).join('');
        } else { preview.style.display = 'none'; }
    }
    removeFile(index) {
        this.selectedFiles.splice(index, 1);
        const dt = new DataTransfer();
        this.selectedFiles.forEach(f => dt.items.add(f));
        document.getElementById('file-input').files = dt.files;
        this.handleFileSelection({ target: { files: dt.files } });
    }
}

document.addEventListener('DOMContentLoaded', () => { window.drewApp = new DrewCommandCenter(); });
